# HifzAmanah specs

**One spec = one user story.** Each of the 70 stories in [user-stories.md](../user-stories.md) has exactly one spec file. Specs are grouped into 17 feature folders, one per epic. Each folder README holds what applies to the whole feature: context, out of scope, edge cases, open questions, the feature test plan, and its definition of done.

- **Spec ID:** `SPEC-US-<nnn>`, in `docs/specs/<feature>/us-<nnn>-<title>.md`.
- **Sections in every spec:** header (spec ID, story, feature, epic, status, priority, origin) · User story · Related functional requirements · Acceptance criteria · Business rules · Validation rules · Edge cases and error handling · Dependencies · Related screens and UI · Related API and data model · Offline and sync behavior · Related E2E test scenarios · Open decisions and blockers · Traceability.
- **Acceptance criteria** come in two parts:
  - **Story criteria:** verbatim from user-stories.md.
  - **Detailed criteria:** Given/When/Then, tagged with the story, e.g. `(US-015)`. They keep their original IDs (`F<nn>-AC<k>`), and every test cites one in its name.
- **Requirement mapping:** SRS.md has no story-to-requirement table. Each spec lists the requirement IDs derived for its story, plus the feature's full requirement set verbatim.
- **Priority:** none of the source documents assigns one, so no spec states a priority.
- **Status:** all specs are **draft**. A spec moves to *ready for tickets* when its open questions are answered.
- **Completion:** a spec is complete only when `npm run e2e:gate -- US-<nnn>` passes. That means every criterion has an E2E test in [`e2e/`](../../e2e/README.md), none is pending, and all of them pass. `npm run e2e:gate -- F<nn>` gates a whole feature.
- **Checks:** `npm run docs:check` (`scripts/check-traceability.mjs`) verifies:
  - one story per spec and no duplicates
  - verbatim story criteria
  - requirement IDs
  - internal links
- **Test file paths** follow the proposed layout in [ARCHITECTURE.md §4](../ARCHITECTURE.md) and may change at scaffolding time.

## Features

| Feature | Stories | Depends on |
|---|---|---|
| [F01 · Identity and authentication](f01-identity-authentication/README.md) | US-001 – US-006 | — |
| [F02 · Organization and roles](f02-organization-roles/README.md) | US-007 – US-009 | F01 |
| [F03 · Classes and students](f03-classes-students/README.md) | US-010 – US-012 | F02 |
| [F04 · Calendar and attendance](f04-calendar-attendance/README.md) | US-013 – US-017 | F03, F12 |
| [F05 · Daily Hifz entry](f05-daily-hifz-entry/README.md) | US-018 – US-023 | F03, F06, F07, F12 |
| [F06 · Quran portions and metadata](f06-quran-portions-metadata/README.md) | US-024 – US-027 | F02 |
| [F07 · Mistakes and quality](f07-mistakes-quality/README.md) | US-028 – US-032 | F05 |
| [F08 · Homework and carry forward](f08-homework-carry-forward/README.md) | US-033 – US-038 | F05, F06 |
| [F09 · Weekly and monthly reports](f09-weekly-monthly-reports/README.md) | US-039 – US-043 | F04, F05, F07, F08 |
| [F10 · Student and Parent access](f10-student-parent-access/README.md) | US-044 – US-046 | F09 |
| [F11 · Localization and accessibility](f11-localization-accessibility/README.md) | US-047 – US-050 | — (cross-cutting) |
| [F12 · Offline and synchronization](f12-offline-sync/README.md) | US-051 – US-054 | F01, F02 |
| [F13 · PDF and print](f13-pdf-print/README.md) | US-055 – US-057 | F09, F10 |
| [F14 · Excel import and export](f14-excel-import-export/README.md) | US-058 – US-061 | F03, F05, F09 |
| [F15 · Analytics and AI recommendations](f15-analytics-ai/README.md) | US-062 – US-065 | F09 |
| [F16 · Notifications](f16-notifications/README.md) | US-066 – US-067 | F01, F10 |
| [F17 · Security, audit, and administration](f17-security-audit-admin/README.md) | US-068 – US-070 | F01, F02 |

**Suggested build order** (follows SRS §12): F01 → F02 → F11 → F03 → F12 → F04 → F06 → F05 → F07 → F08 → F09 → F17 → F10 → F13 → F14 → F15 → F16.

## All specs

| Spec | Story | Feature | Detailed criteria |
|---|---|---|---|
| [SPEC-US-001](f01-identity-authentication/us-001-sign-in-with-user-id.md) | US-001 — Sign in with User ID | F01 | 6 |
| [SPEC-US-002](f01-identity-authentication/us-002-recover-password-by-email-otp.md) | US-002 — Recover password by email OTP | F01 | 5 |
| [SPEC-US-003](f01-identity-authentication/us-003-admin-creates-accounts.md) | US-003 — Admin creates accounts | F01 | 3 |
| [SPEC-US-004](f01-identity-authentication/us-004-admin-sets-initial-passwords.md) | US-004 — Admin sets initial passwords | F01 | 3 |
| [SPEC-US-005](f01-identity-authentication/us-005-use-shared-email-safely.md) | US-005 — Use shared email safely | F01 | 2 |
| [SPEC-US-006](f01-identity-authentication/us-006-separate-accounts-per-madrasa.md) | US-006 — Separate accounts per madrasa | F01 | 3 |
| [SPEC-US-007](f02-organization-roles/us-007-create-madrasa-workspace.md) | US-007 — Create madrasa workspace | F02 | 5 |
| [SPEC-US-008](f02-organization-roles/us-008-restrict-teacher-scope.md) | US-008 — Restrict teacher scope | F02 | 4 |
| [SPEC-US-009](f02-organization-roles/us-009-audit-sensitive-changes.md) | US-009 — Audit sensitive changes | F02 | 4 |
| [SPEC-US-010](f03-classes-students/us-010-create-and-maintain-classes.md) | US-010 — Create and maintain classes | F03 | 5 |
| [SPEC-US-011](f03-classes-students/us-011-create-student-profiles.md) | US-011 — Create student profiles | F03 | 5 |
| [SPEC-US-012](f03-classes-students/us-012-enroll-students.md) | US-012 — Enroll students | F03 | 3 |
| [SPEC-US-013](f04-calendar-attendance/us-013-configure-class-timetable.md) | US-013 — Configure class timetable | F04 | 2 |
| [SPEC-US-014](f04-calendar-attendance/us-014-manage-holidays-and-closures.md) | US-014 — Manage holidays and closures | F04 | 3 |
| [SPEC-US-015](f04-calendar-attendance/us-015-record-attendance-in-bulk.md) | US-015 — Record attendance in bulk | F04 | 7 |
| [SPEC-US-016](f04-calendar-attendance/us-016-request-excused-absence.md) | US-016 — Request excused absence | F04 | 2 |
| [SPEC-US-017](f04-calendar-attendance/us-017-approve-excused-absence.md) | US-017 — Approve excused absence | F04 | 3 |
| [SPEC-US-018](f05-daily-hifz-entry/us-018-create-individual-daily-report.md) | US-018 — Create individual daily report | F05 | 5 |
| [SPEC-US-019](f05-daily-hifz-entry/us-019-choose-daily-report-mode.md) | US-019 — Choose daily report mode | F05 | 4 |
| [SPEC-US-020](f05-daily-hifz-entry/us-020-record-sabaq.md) | US-020 — Record Sabaq | F05 | 1 |
| [SPEC-US-021](f05-daily-hifz-entry/us-021-record-sabqi-portions.md) | US-021 — Record Sabqi portions | F05 | 2 |
| [SPEC-US-022](f05-daily-hifz-entry/us-022-record-manzil-portions.md) | US-022 — Record Manzil portions | F05 | 2 |
| [SPEC-US-023](f05-daily-hifz-entry/us-023-record-repeated-attempts.md) | US-023 — Record repeated attempts | F05 | 2 |
| [SPEC-US-024](f06-quran-portions-metadata/us-024-maintain-quran-metadata.md) | US-024 — Maintain Quran metadata | F06 | 4 |
| [SPEC-US-025](f06-quran-portions-metadata/us-025-select-para-and-ayat-range.md) | US-025 — Select Para and Ayat range | F06 | 3 |
| [SPEC-US-026](f06-quran-portions-metadata/us-026-use-15-line-mushaf.md) | US-026 — Use 15-line Mushaf | F06 | 2 |
| [SPEC-US-027](f06-quran-portions-metadata/us-027-select-portion-quantities.md) | US-027 — Select portion quantities | F06 | 6 |
| [SPEC-US-028](f07-mistakes-quality/us-028-record-mistake-categories.md) | US-028 — Record mistake categories | F07 | 3 |
| [SPEC-US-029](f07-mistakes-quality/us-029-set-mistake-severity.md) | US-029 — Set mistake severity | F07 | 1 |
| [SPEC-US-030](f07-mistakes-quality/us-030-flag-repeated-mistakes.md) | US-030 — Flag repeated mistakes | F07 | 1 |
| [SPEC-US-031](f07-mistakes-quality/us-031-rate-quality-1-5.md) | US-031 — Rate quality 1–5 | F07 | 6 |
| [SPEC-US-032](f07-mistakes-quality/us-032-set-overall-performance-label.md) | US-032 — Set overall performance label | F07 | 2 |
| [SPEC-US-033](f08-homework-carry-forward/us-033-create-structured-homework.md) | US-033 — Create structured homework | F08 | 2 |
| [SPEC-US-034](f08-homework-carry-forward/us-034-calculate-remaining-work.md) | US-034 — Calculate remaining work | F08 | 2 |
| [SPEC-US-035](f08-homework-carry-forward/us-035-suggest-carry-forward.md) | US-035 — Suggest carry-forward | F08 | 3 |
| [SPEC-US-036](f08-homework-carry-forward/us-036-review-homework-suggestion.md) | US-036 — Review homework suggestion | F08 | 2 |
| [SPEC-US-037](f08-homework-carry-forward/us-037-confirm-next-assignment.md) | US-037 — Confirm next assignment | F08 | 3 |
| [SPEC-US-038](f08-homework-carry-forward/us-038-preserve-homework-history.md) | US-038 — Preserve homework history | F08 | 4 |
| [SPEC-US-039](f09-weekly-monthly-reports/us-039-view-weekly-report.md) | US-039 — View weekly report | F09 | 9 |
| [SPEC-US-040](f09-weekly-monthly-reports/us-040-view-monthly-report.md) | US-040 — View monthly report | F09 | 3 |
| [SPEC-US-041](f09-weekly-monthly-reports/us-041-separate-attendance-and-performance.md) | US-041 — Separate attendance and performance | F09 | 2 |
| [SPEC-US-042](f09-weekly-monthly-reports/us-042-show-excused-and-normal-absence.md) | US-042 — Show excused and normal absence | F09 | 1 |
| [SPEC-US-043](f09-weekly-monthly-reports/us-043-show-portion-level-outcomes.md) | US-043 — Show portion-level outcomes | F09 | 1 |
| [SPEC-US-044](f10-student-parent-access/us-044-student-views-own-reports.md) | US-044 — Student views own reports | F10 | 4 |
| [SPEC-US-045](f10-student-parent-access/us-045-parent-views-linked-student-reports.md) | US-045 — Parent views linked student reports | F10 | 4 |
| [SPEC-US-046](f10-student-parent-access/us-046-protect-private-teacher-notes.md) | US-046 — Protect private teacher notes | F10 | 4 |
| [SPEC-US-047](f11-localization-accessibility/us-047-use-english-interface.md) | US-047 — Use English interface | F11 | 5 |
| [SPEC-US-048](f11-localization-accessibility/us-048-use-urdu-interface.md) | US-048 — Use Urdu interface | F11 | 3 |
| [SPEC-US-049](f11-localization-accessibility/us-049-use-roman-urdu-interface.md) | US-049 — Use Roman Urdu interface | F11 | 2 |
| [SPEC-US-050](f11-localization-accessibility/us-050-preserve-quran-arabic-text.md) | US-050 — Preserve Quran Arabic text | F11 | 3 |
| [SPEC-US-051](f12-offline-sync/us-051-save-daily-work-offline.md) | US-051 — Save daily work offline | F12 | 4 |
| [SPEC-US-052](f12-offline-sync/us-052-sync-queued-changes.md) | US-052 — Sync queued changes | F12 | 6 |
| [SPEC-US-053](f12-offline-sync/us-053-see-sync-status.md) | US-053 — See sync status | F12 | 3 |
| [SPEC-US-054](f12-offline-sync/us-054-resolve-conflicting-edits.md) | US-054 — Resolve conflicting edits | F12 | 3 |
| [SPEC-US-055](f13-pdf-print/us-055-generate-professional-pdf.md) | US-055 — Generate professional PDF | F13 | 5 |
| [SPEC-US-056](f13-pdf-print/us-056-customize-report-template.md) | US-056 — Customize report template | F13 | 4 |
| [SPEC-US-057](f13-pdf-print/us-057-apply-report-permissions-to-pdf.md) | US-057 — Apply report permissions to PDF | F13 | 3 |
| [SPEC-US-058](f14-excel-import-export/us-058-import-student-workbook.md) | US-058 — Import student workbook | F14 | 6 |
| [SPEC-US-059](f14-excel-import-export/us-059-import-daily-records.md) | US-059 — Import daily records | F14 | 5 |
| [SPEC-US-060](f14-excel-import-export/us-060-preview-import-changes.md) | US-060 — Preview import changes | F14 | 5 |
| [SPEC-US-061](f14-excel-import-export/us-061-export-authorized-data.md) | US-061 — Export authorized data | F14 | 4 |
| [SPEC-US-062](f15-analytics-ai/us-062-view-deterministic-analytics.md) | US-062 — View deterministic analytics | F15 | 3 |
| [SPEC-US-063](f15-analytics-ai/us-063-receive-ai-recommendations.md) | US-063 — Receive AI recommendations | F15 | 6 |
| [SPEC-US-064](f15-analytics-ai/us-064-configure-ai-provider-and-limits.md) | US-064 — Configure AI provider and limits | F15 | 3 |
| [SPEC-US-065](f15-analytics-ai/us-065-control-ai-data-sharing.md) | US-065 — Control AI data sharing | F15 | 3 |
| [SPEC-US-066](f16-notifications/us-066-receive-android-push-notifications.md) | US-066 — Receive Android push notifications | F16 | 7 |
| [SPEC-US-067](f16-notifications/us-067-manage-notification-preferences.md) | US-067 — Manage notification preferences | F16 | 3 |
| [SPEC-US-068](f17-security-audit-admin/us-068-enforce-tenant-isolation.md) | US-068 — Enforce tenant isolation | F17 | 5 |
| [SPEC-US-069](f17-security-audit-admin/us-069-review-audit-history.md) | US-069 — Review audit history | F17 | 4 |
| [SPEC-US-070](f17-security-audit-admin/us-070-protect-account-recovery.md) | US-070 — Protect account recovery | F17 | 4 |
