# SPEC-US-006 · Separate accounts per madrasa

| | |
|---|---|
| **Spec ID** | SPEC-US-006 |
| **User story** | US-006 |
| **Feature** | [F01 · Identity and authentication](README.md) |
| **Epic** | EPIC 1 — Identity and Authentication ([user-stories.md](../../user-stories.md)) |
| **Status** | draft |
| **Priority** | Not specified in the source documents (SRS, user-stories.md, feature specs). None is assigned here. |
| **Split from** | `docs/specs/F01-identity-authentication.md` on 2026-10-30 |

## User story

**US-006 — Separate accounts per madrasa**

As a user associated with multiple madaris, I want a separate account and User ID for each madrasa.

Spec wording (from F01):

- **US-006:** As a user in several madaris, I want a separate account and User ID for each madrasa, so that each madrasa's data stays separate.

**Feature context** (shared by every story in F01, copied from the feature spec):

> Every user signs in with a User ID that their madrasa gives them, never with an email. A Student and a Parent may share one email, and a person who belongs to several madaris has a separate account in each, so email cannot identify an account. The Madrasa Admin creates every Teacher, Student, and Parent account and sets its first password.
>
> There is no code yet. This feature creates the `identity` module ([ARCHITECTURE.md §5, §7.1](../../ARCHITECTURE.md)), which consists of:
> - the `users`, `sessions`, and `password_reset_otps` tables
> - Argon2id password hashing
> - a short-lived access token plus a rotating refresh token
>
> Everything else depends on this feature, so build it first.

## Related functional requirements

Requirements this story covers. SRS.md has no story-to-requirement table, so this list is derived from the requirement text and the criteria below.

- **Functional:** FR-AUTH-011, FR-ORG-006
- **Non-functional:** Not applicable
- **SRS acceptance tests cited:** None

Feature requirement set (verbatim from F01): FR-AUTH-001…011, FR-SEC-010, NFR-SEC-003

## Acceptance criteria

### Story acceptance criteria

Verbatim from [user-stories.md](../../user-stories.md).

1. A person who belongs to more than one madrasa has a separate account with a unique User ID in each madrasa.
2. The same email address may be used on those accounts; signing in to one account gives access only to that madrasa's data.
3. Deactivating or changing the account in one madrasa does not affect the person's account in another madrasa.

### Detailed acceptance criteria

Verbatim from the F01 feature spec. The original IDs are kept because tests cite them.

- **F01-AC20** — **(US-006) Given** a person with accounts in Madrasa A and Madrasa B, **when** they are signed in to the A account and request a Madrasa B record by its ID, **then** the response is "not found", exactly as for an ID that does not exist.
- **F01-AC21** — **(US-006) Given** a person whose Madrasa A account has been deactivated, **when** they sign in to their Madrasa B account, **then** sign-in works normally.
- **F01-AC22** — **(US-006) Given** a deactivated account, **when** it tries to sign in or use an existing session, **then** it is refused and its sessions are revoked.

## Business rules

No SRS §9 business rule is specific to this story. The rules it follows are stated in the criteria above.

## Validation rules

Stated in these criteria: F01-AC22.

## Edge cases and error handling

Rows from the F01 edge-case table that apply to this story (verbatim):

| Situation | What should happen |
|---|---|
| Two accounts are used on one device | Each account's local data is kept separate; signing in to one never shows the other's cached data |

**Out of scope for the whole feature** (verbatim from F01):

- Signing in with email or phone number.
- Self sign-up for Teacher, Student, or Parent.
- Email verification to activate an account (FR-AUTH-008).
- Forcing a password change on first sign-in.
- 2FA and recovery codes (still open: SRS §13 #1).
- Social or SSO login, and SMS OTP.
- One account that switches between several madaris.

## Dependencies

- **Feature F01 depends on:** — (from the spec index)
- **Features referenced by this story's criteria and edge cases:** None
- **Other stories referenced:** None
- **Other stories in F01:** [US-001](us-001-sign-in-with-user-id.md), [US-002](us-002-recover-password-by-email-otp.md), [US-003](us-003-admin-creates-accounts.md), [US-004](us-004-admin-sets-initial-passwords.md), [US-005](us-005-use-shared-email-safely.md)

## Related screens and UI

- **Feature flow** (from F01): Sign-in and forgot password ([design.md §4.2](../../design.md)); Admin account management (design gap)

[design.md §13](../../design.md) story-to-screen map (verbatim):

| Story | Screen (this document) | Key interaction | Required states beyond standard | Validation shown | Accessibility / localization specifics |
|---|---|---|---|---|---|
| US-003, US-004, US-005, US-006 | Account management (design gap; FormField and §5.11 dialogs) | Admin creates Teacher/Student/Parent account, assigns User ID, sets initial password, optional email | Offline (creation needs network) | User ID unique; password policy; shared Student/Parent email allowed | Password field show/hide; no email-as-login hint |

## Related API and data model

- **Modules** ([ARCHITECTURE.md §18](../../ARCHITECTURE.md)): `identity`
- Tables and services are described in the feature context above and in [ARCHITECTURE.md](../../ARCHITECTURE.md). Concrete API routes are not defined yet (SRS §13 #1).

## Offline and sync behavior


And in these edge cases (see above):

- Two accounts are used on one device

## Related E2E test scenarios

**Completion gate:** this spec is complete only when `npm run e2e:gate -- US-006` passes. That means every criterion has an E2E test, none is pending, and all of them pass ([e2e/README.md](../../../e2e/README.md)).

**API (Playwright):**

- [e2e/api/f01-identity.spec.ts](../../../e2e/api/f01-identity.spec.ts) — F01-AC20 (US-006) a Madrasa B ID requested from Madrasa A returns not found
- [e2e/api/f01-identity.spec.ts](../../../e2e/api/f01-identity.spec.ts) — F01-AC21 (US-006) deactivating the Madrasa A account leaves the Madrasa B account working
- [e2e/api/f01-identity.spec.ts](../../../e2e/api/f01-identity.spec.ts) — F01-AC22 (US-006) a deactivated account cannot sign in and loses its sessions

**Mobile (Maestro):**

- None

**Unit (Vitest):**

- None

## Open decisions and blockers

None specific to this story. See the [feature open questions](README.md#open-questions).

## Traceability

- **Story:** US-006 → SPEC-US-006 (this file)
- **Detailed criteria:** F01-AC20, F01-AC21, F01-AC22
- **Requirements:** FR-AUTH-011, FR-ORG-006
- **SRS acceptance tests:** None
- **Business rules:** None
- **Design:** design.md §13; **Architecture:** ARCHITECTURE.md §18 epic 1
- **Previous location:** `docs/specs/F01-identity-authentication.md`
