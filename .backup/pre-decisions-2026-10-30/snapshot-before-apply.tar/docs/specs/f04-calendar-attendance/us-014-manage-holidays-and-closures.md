# SPEC-US-014 · Manage holidays and closures

| | |
|---|---|
| **Spec ID** | SPEC-US-014 |
| **User story** | US-014 |
| **Feature** | [F04 · Calendar and attendance](README.md) |
| **Epic** | EPIC 4 — Calendar and Attendance ([user-stories.md](../../user-stories.md)) |
| **Status** | draft |
| **Priority** | Not specified in the source documents (SRS, user-stories.md, feature specs). None is assigned here. |
| **Split from** | `docs/specs/F04-calendar-attendance.md` on 2026-10-30 |

## User story

**US-014 — Manage holidays and closures**

As an Admin, I want to mark holidays and no-class dates.

Spec wording (from F04):

- **US-014:** As an Admin, I want to mark holidays and no-class dates, so that those days are never counted as absences.

**Feature context** (shared by every story in F04, copied from the feature spec):

> Attendance answers a different question from performance. Attendance is about whether the student was there; performance is about how they recited. The schedule decides which days count. A holiday or an unscheduled day can never become an absence. Bulk Entry exists so a teacher can mark a whole class quickly, and it records **only Present or Absent**.
>
> Excused absence takes two steps: the Teacher marks it, then the Admin decides.
>
> There is no code yet. This feature builds the `calendar` module ([ARCHITECTURE.md §6.3, §6.5](../../ARCHITECTURE.md)): the `class_schedules`, `calendar_exceptions`, and `attendance_records` tables. Attendance writes go through the offline outbox (F12).

## Related functional requirements

Requirements this story covers. SRS.md has no story-to-requirement table, so this list is derived from the requirement text and the criteria below.

- **Functional:** FR-CAL-002, FR-CAL-004, FR-CAL-005
- **Non-functional:** Not applicable
- **SRS acceptance tests cited:** None

Feature requirement set (verbatim from F04): FR-CAL-001…006, FR-DAY-002A, FR-DAY-007, FR-ATT-002, NFR-UX-004

## Acceptance criteria

### Story acceptance criteria

Verbatim from [user-stories.md](../../user-stories.md).

1. Attendance is stored separately from recitation/performance status.
2. Bulk attendance offers only Present and Absent; no Hifz portion or quality fields are included.
3. Holidays, unscheduled dates, and no-class days are not counted as absences; excused absence requires Admin approval.

### Detailed acceptance criteria

Verbatim from the F04 feature spec. The original IDs are kept because tests cite them.

- **F04-AC3** — **(US-014) Given** a holiday declared for the whole madrasa on a date, **when** that date is reported, **then** it shows as a holiday, and no student is counted absent for it.
- **F04-AC4** — **(US-014) Given** a no-class exception for one class on a date, **when** that date is reported, **then** only that class's students show "no class" for it.
- **F04-AC5** — **(US-014) Given** a date that is a holiday, **when** a Teacher opens Bulk Entry for that date, **then** the screen says it is a holiday and that no absence is recorded automatically.

## Business rules

From SRS §9 (verbatim):

- **BR-7:** Holidays and unscheduled dates are not absences.

## Validation rules

No validation rule beyond the criteria above.

## Edge cases and error handling

Rows from the F04 edge-case table that apply to this story (verbatim):

| Situation | What should happen |
|---|---|
| A holiday is added after attendance was already recorded for that date | Open question; never silently delete the recorded attendance |

**Out of scope for the whole feature** (verbatim from F04):

- Any Hifz, quality, mistake, or excused-absence field in Bulk Entry.
- Attendance states other than Present and Absent (late, leave, half-day).
- Parents or students requesting an excuse.
- Absence push notifications (event catalogue still open, F16).
- Automatic absence on unscheduled days.

## Dependencies

- **Feature F04 depends on:** F03, F12 (from the spec index)
- **Features referenced by this story's criteria and edge cases:** None
- **Other stories referenced:** None
- **Other stories in F04:** [US-013](us-013-configure-class-timetable.md), [US-015](us-015-record-attendance-in-bulk.md), [US-016](us-016-request-excused-absence.md), [US-017](us-017-approve-excused-absence.md)

## Related screens and UI

- **Feature flow** (from F04): Timetable and holidays ([design.md §4.14](../../design.md)); Bulk Entry ([§4.8](../../design.md)); Daily Entry Step 2 ([§4.7](../../design.md))

[design.md §13](../../design.md) story-to-screen map (verbatim):

| Story | Screen (this document) | Key interaction | Required states beyond standard | Validation shown | Accessibility / localization specifics |
|---|---|---|---|---|---|
| US-013, US-014 | §4.14 Timetable and holidays | Define schedule; add holiday or closure | No records | Holiday notice in Daily and Bulk Entry: no automatic absence | Day types as text labels; no danger color for holidays |

## Related API and data model

- **Modules** ([ARCHITECTURE.md §18](../../ARCHITECTURE.md)): `calendar`
- Tables and services are described in the feature context above and in [ARCHITECTURE.md](../../ARCHITECTURE.md). Concrete API routes are not defined yet (SRS §13 #1).

## Offline and sync behavior

Nothing specific to this story in the source documents.

## Related E2E test scenarios

**Completion gate:** this spec is complete only when `npm run e2e:gate -- US-014` passes. That means every criterion has an E2E test, none is pending, and all of them pass ([e2e/README.md](../../../e2e/README.md)).

**API (Playwright):**

- [e2e/api/f04-attendance.spec.ts](../../../e2e/api/f04-attendance.spec.ts) — F04-AC3 (US-014) a madrasa holiday is shown as a holiday with no absences
- [e2e/api/f04-attendance.spec.ts](../../../e2e/api/f04-attendance.spec.ts) — F04-AC4 (US-014) a no-class exception affects only that class

**Mobile (Maestro):**

- [e2e/mobile/f04-attendance/schedule-holidays.yaml](../../../e2e/mobile/f04-attendance/schedule-holidays.yaml) — F04 calendar — schedule, holiday, class exception, holiday notice in Bulk Entry

**Unit (Vitest):**

- [packages/domain/calendar/calendar.test.ts](../../../packages/domain/calendar/calendar.test.ts) — F04-AC3 (US-014) a madrasa-wide holiday is a holiday, never an absence
- [packages/domain/calendar/calendar.test.ts](../../../packages/domain/calendar/calendar.test.ts) — F04-AC4 (US-014) a no-class exception applies only to that class

## Open decisions and blockers

Open questions from F04 that apply to this story (verbatim):

- [ ] What happens to recorded attendance when a holiday is declared on that date afterwards?

## Traceability

- **Story:** US-014 → SPEC-US-014 (this file)
- **Detailed criteria:** F04-AC3, F04-AC4, F04-AC5
- **Requirements:** FR-CAL-002, FR-CAL-004, FR-CAL-005
- **SRS acceptance tests:** None
- **Business rules:** SRS §9 #7
- **Design:** design.md §13; **Architecture:** ARCHITECTURE.md §18 epic 4
- **Previous location:** `docs/specs/F04-calendar-attendance.md`
