# HifzAmanah documentation

Planning documents for HifzAmanah, an Android-first, offline-capable Hifz management app. No application code exists yet.

| Document | What it holds |
|---|---|
| [00-product-brief.md](00-product-brief.md) | One-page product summary |
| [SRS.md](SRS.md) | Requirements (FR-*/NFR-*), business rules (§9), acceptance tests (§10), finalized decisions (§16), open gates (§13) |
| [user-stories.md](user-stories.md) | 70 user stories (US-001…US-070) with 188 story acceptance criteria |
| [specs/](specs/README.md) | **One spec per user story** (70 specs in 17 feature folders), with 252 detailed criteria |
| [design.md](design.md) | UI/UX: tokens, components, screens, open design decisions (§11), story-to-screen map (§13) |
| [ARCHITECTURE.md](ARCHITECTURE.md) | How to build it; items marked "Proposed" still need approval |
| [AGENTS.md](AGENTS.md) | Rules for AI coding agents working in this repository |

**Source of truth when documents disagree:** see [AGENTS.md §2](AGENTS.md).

## Tests written ahead of implementation

- **E2E:** [e2e/README.md](../e2e/README.md).
  - A spec is complete only when `npm run e2e:gate -- US-<nnn>` passes.
- **Unit:** `it.todo` placeholders under `apps/` and `packages/`, run with `npm test`.

## Checks

| Check | Command |
|---|---|
| Specs: one story per spec, no duplicates, verbatim story criteria, requirement IDs, links | `npm run docs:check` |
| Every detailed criterion has an E2E test | `npm run e2e:trace` |
