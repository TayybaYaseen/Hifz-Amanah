@docs/AGENTS.md
